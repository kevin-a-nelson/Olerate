const ENV = {
  isA: false,
  useFetchedData: false,
  useLocalData: false,
  useHardCodedData: false,
  failAPICall: false,
};
